package com.cookandroid.capstone_front_android.network;

import com.cookandroid.capstone_front_android.data.JoinData;
import com.cookandroid.capstone_front_android.data.JoinResponse;
import com.cookandroid.capstone_front_android.data.LoginData;
import com.cookandroid.capstone_front_android.data.LoginResponse;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ServiceApi {
    @POST("/users/login")
    Call<LoginResponse> userLogin(@Body LoginData data);

    @POST("/users/new")
    Call<JoinResponse> userJoin(@Body JoinData data);
}