package com.cookandroid.capstone_front_android;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.capstone_front_android.data.JoinData;
import com.cookandroid.capstone_front_android.data.JoinResponse;
import com.cookandroid.capstone_front_android.network.RetrofitClient;
import com.cookandroid.capstone_front_android.network.ServiceApi;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class JoinActivity extends AppCompatActivity {
    private EditText userId;
    private EditText password;
    private EditText phoneNumber;
    private EditText name;
    private EditText email;
    private EditText nickname;
    private Button register;

    private ServiceApi service;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userId = (EditText) findViewById(R.id.userId);
        password = (EditText) findViewById(R.id.password);
        phoneNumber = (EditText) findViewById(R.id.phoneNumber);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        nickname = (EditText) findViewById(R.id.nickname);
        register = (Button) findViewById(R.id.register);



        service = RetrofitClient.getClient().create(ServiceApi.class);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptJoin();
            }
        });
    }

    private void attemptJoin() {
        userId.setError(null);
        password.setError(null);
        email.setError(null);
        nickname.setError(null);

        String uname = userId.getText().toString();
        String upassword = password.getText().toString();
        String uemail = email.getText().toString();
        String unickname = nickname.getText().toString();


        boolean cancel = false;
        View focusView = null;

        // 아이디 유효성 검사
        if (uname.isEmpty()) {
            userId.setError("아이디는 4~10글자 사이로 입력해주세요.");
            focusView = userId;
            cancel = true;
        }

        // 비밀번호 유효성 검사
        if (upassword.isEmpty()) {
            password.setError("비밀번호를 입력해주세요.");
            focusView = password;
            cancel = true;
        } else if (!isPasswordValid(upassword)) {
            password.setError("비밀번호는 6~10글자 사이로 입력해주세요");
            focusView = password;
            cancel = true;
        }

        // 이메일 유효성 검사
        if (uemail.isEmpty()) {
            email.setError("이메일을 입력해주세요.");
            focusView = email;
            cancel = true;
        } else if (!isEmailValid(uemail)) {
            email.setError("@를 포함한 유효한 이메일을 입력해주세요.");
            focusView = email;
            cancel = true;
        }

        // 닉네임 유효성 검사
        if (unickname.isEmpty()) {
            nickname.setError("닉네임은 2~10글자 사이로 입력해주세요");
            focusView = nickname;
            cancel = true;
        }


        if (cancel) {
            focusView.requestFocus();
        } else {
            startJoin(new JoinData(uname,upassword,uemail,unickname));

        }
    }

    private void startJoin(JoinData data) {
        service.userJoin(data).enqueue(new Callback<JoinResponse>() {
            @Override
            public void onResponse(Call<JoinResponse> call, Response<JoinResponse> response) {
                JoinResponse result = response.body();
                Toast.makeText(JoinActivity.this, result.getMessage(), Toast.LENGTH_SHORT).show();


                if (result.getCode() == 200) {
                    finish();
                }
            }

            @Override
            public void onFailure(Call<JoinResponse> call, Throwable t) {
                Toast.makeText(JoinActivity.this, "회원가입 에러 발생", Toast.LENGTH_SHORT).show();
                Log.e("회원가입 에러 발생", t.getMessage());

            }
        });
    }

    private boolean isEmailValid(String email) {
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        return password.length() >= 6;
    }


}
