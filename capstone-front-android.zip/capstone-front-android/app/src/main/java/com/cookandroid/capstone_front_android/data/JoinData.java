package com.cookandroid.capstone_front_android.data;

import com.google.gson.annotations.SerializedName;

public class JoinData {
    @SerializedName("userId")
    private String userId;

    @SerializedName("name")
    private String name;

    @SerializedName("password")
    private String password;

    @SerializedName("nickname")
    private String nickname;

    @SerializedName("email")
    private String email;

    @SerializedName("phoneNumber")
    private String phoneNumber;

    public JoinData(String userId, String name, String password, String nickname) {
        this.userId = userId;
        this.name = name;
        this.password = password;
        this.nickname = nickname;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }


}
